# Codebase for the blog post [Test Spring WebClient with MockWebServer from OkHttp](https://rieckpil.de/test-spring-webclient-with-mockwebserver-from-okhttp/)

Steps to run this project:

1. Clone this Git repository
2. Navigate to the folder `spring-web-client-testing-with-mockwebserver`
3. Run `mvn test` to execute the tests
